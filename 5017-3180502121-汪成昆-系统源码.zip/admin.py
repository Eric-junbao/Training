from flask_admin import Admin,AdminIndexView
from run import app
from flask_admin.contrib.sqla import ModelView
from flask import current_app,redirect,url_for,request
from models import db,User,BanJi,KeCheng,TongGao,ChengJi,JiaoShi,PingLun,ZhiLiao,QianDao,My_qiandao,TiMu,My_timu

class MyModelView(ModelView):
    def inaccessible_callback(self, name, **kwargs):
        # redirect to login page if user doesn't have access
        return redirect(url_for('login', next=request.url))

class MyUser(MyModelView):
    column_labels = dict(
        name='账号',
        email='邮箱',
        pwd='密码',
        mob = '手机号',
        set ='性别',
        type ='权限',
        banji_id = '关联班级表',
        chengji = '关联成绩表',
        pinglun = '关联评论表',
        my_timu = '关联作业表',
    )
    column_searchable_list = ('name',)



class MyBanJi(MyModelView):
    column_labels = dict(
        name = '班级名',
        banzhuren = '班主任',
        user = '关联用户表',
        kecheng = '关联课程表',
        qiandao = '关联签到表'
    )
    column_searchable_list = ('name',)

class MyKeCheng(MyModelView):
    column_labels = dict(
        name = '课程名',
        zhaungjie = '章节名称',
        beizhu = '备注',
        banji_id = '关联班级表',
        chengji = '关联成绩表',
        zhiliao = '关联资料课件表',
        qiandao = '关联签到表',
        timu = '关联题目表',
    )
    column_searchable_list = ('name',)


class MyTongGao(MyModelView):
    column_labels = dict(
        name = '标题',
        content = '内容',
        pinglun= '关联评论表',
    )
    column_searchable_list = ('name',)


class MyJiaoShi(MyModelView):
    column_labels = dict(
        name='账号',
        email='邮箱',
        pwd='密码',
    )
    column_searchable_list = ('name',)

class MyPingLun(MyModelView):
    column_labels = dict(
        name = '标题',
        content = '内容',
        user_id = '发布用户',
        tonggao_id = '关联讨论'
    )
    column_searchable_list = ('name',)


class MyZhiLiao(MyModelView):
    column_labels = dict(
        kecheng_id = '关联课程',
        name = '资料名',
    )
    column_searchable_list = ('name',)

class MyQianDao(MyModelView):
    column_labels = dict(
        title = '标题',
        faburen = '发布人',
        kecheng_id = '签到课程',
        banji_id = '签到班级',
        my_qiandao = '关联学生签到表'
    )
    column_searchable_list = ('title',)


class MyMy_qiandao(MyModelView):
    column_labels = dict(
        user_id = '签到用户',
        qiandao_id = '关联签到表',
    )


class MyTiMu(MyModelView):
    column_labels = dict(
        title = '题目',
        kecheng_id = '所属课程'
    )
    column_searchable_list = ('title',)

class MyMy_timu(MyModelView):
    column_labels = dict(
        title = '回答',
        user_id = '回答用户',
        timu_id = '回答题目',
        fenshu = '分数'
    )
    column_searchable_list = ('title',)


admin = Admin(app=app, name='后台管理系统',template_mode='bootstrap3', base_template='admin/mybase.html',index_view=AdminIndexView(
        name='导航栏',
        template='admin/welcome.html',
        url='/admin'
    ))
admin.add_view(MyBanJi(BanJi, db.session,name='班级管理'))
admin.add_view(MyUser(User, db.session,name='用户管理'))
admin.add_view(MyKeCheng(KeCheng, db.session,name='课程信息管理'))
admin.add_view(MyTongGao(TongGao, db.session,name='在线讨论管理'))
admin.add_view(MyJiaoShi(JiaoShi, db.session,name='教师管理'))
admin.add_view(MyPingLun(PingLun, db.session,name='评论管理'))
admin.add_view(MyZhiLiao(ZhiLiao, db.session,name='资料管理'))
admin.add_view(MyQianDao(QianDao, db.session,name='签到管理'))
admin.add_view(MyMy_qiandao(My_qiandao, db.session,name='学生签到管理'))
admin.add_view(MyTiMu(TiMu, db.session,name='题目管理'))
admin.add_view(MyMy_timu(My_timu, db.session,name='学生答题管理'))

if __name__ == '__main__':
    app.run(debug=True)