# !/usr/bin/env python
# _*_ coding: utf-8 _*_
import datetime
import os

from flask import request, render_template,session,redirect, url_for
from models import *
import models
from sqlalchemy import or_,and_

@app.route('/', methods=['GET', 'POST'])
@app.route('/index', methods=['GET', 'POST'])
def jiaoshi():
    uuid = session.get('uuid')
    if not User.query.get(uuid):
        return redirect(url_for('login'))
    if request.method == 'GET':
        if User.query.get(uuid).type =='admin':
            search = request.args.get('search', '')
            if search:
                datas = KeCheng.query.filter(and_(KeCheng.name.like("%{}%".format(search)))).all()
            else:
                datas = KeCheng.query.all()
            return render_template('app/table.html',**locals())
        else:
            return redirect(url_for('index'))

@app.route('/jiaoshi', methods=['GET', 'POST'])
def index():
    uuid = session.get('uuid')
    if not User.query.get(uuid):
        return redirect(url_for('login'))
    if request.method == 'GET':
            search = request.args.get('search', '')
            if search:
                datas = KeCheng.query.filter(and_(KeCheng.banji_id==User.query.get(uuid).banji_id,KeCheng.name.like("%{}%".format(search)))).all()
            else:
                datas = KeCheng.query.filter(and_(KeCheng.banji_id==User.query.get(uuid).banji_id)).all()
            return render_template('xuesheng/table.html',**locals())



@app.route('/banji', methods=['GET', 'POST'])
def banji():
    uuid = session.get('uuid')
    if not User.query.get(uuid):
        return redirect(url_for('login'))
    if request.method == 'GET':
        if User.query.get(uuid).type =='admin':
            tid = request.args.get('tid')
            datas = models.User.query.filter(models.User.banji_id==tid).all()
            return render_template('app/banji.html',**locals())
        else:
            tid = request.args.get('tid')
            datas = models.User.query.filter(models.User.banji_id == tid).all()
            return render_template('xuesheng/banji.html', **locals())

@app.route('/ziliao', methods=['GET', 'POST'])
def ziliao():
    uuid = session.get('uuid')
    if not User.query.get(uuid):
        return redirect(url_for('login'))
    if request.method == 'GET':
        if User.query.get(uuid).type =='admin':
            tid = request.args.get('tid')
            result = models.KeCheng.query.get(tid)
            datas = models.ZhiLiao.query.filter(models.ZhiLiao.kecheng_id==tid).all()
            return render_template('app/ziliao.html',**locals())
        else:
            tid = request.args.get('tid')
            result = models.KeCheng.query.get(tid)
            datas = models.ZhiLiao.query.filter(models.ZhiLiao.kecheng_id == tid).all()
            return render_template('xuesheng/ziliao.html', **locals())

@app.route('/qiandao', methods=['GET', 'POST'])
def qiandao():
    uuid = session.get('uuid')
    if not User.query.get(uuid):
        return redirect(url_for('login'))
    if request.method == 'GET':
        if User.query.get(uuid).type =='admin':
            result = models.QianDao.query.all()
            datas = []
            for resu in result:
                dicts = {}
                dicts['resu'] = resu
                dicts['title'] = resu.title
                dicts['datetime'] = resu.datetime
                dicts['banji'] = len(models.User.query.filter(models.User.banji_id==resu.banji_id).all())
                dicts['qiandao'] = len(models.My_qiandao.query.filter(models.My_qiandao.qiandao_id == resu.id).all())
                datas.append(dicts)
            return render_template('app/qiandao.html',**locals())
        else:
            result = models.QianDao.query.all()
            datas = []
            for resu in result:
                dicts = {}
                dicts['resu'] = resu
                if models.My_qiandao.query.filter(and_(models.My_qiandao.qiandao_id == resu.id,models.My_qiandao.user_id==uuid)).all():
                    dicts['status'] = '已签到'
                else:
                    dicts['status'] = 'False'
                datas.append(dicts)
            return render_template('xuesheng/qiandao.html',**locals())

@app.route('/qd_user', methods=['GET', 'POST'])
def qd_user():
    uuid = session.get('uuid')
    if not User.query.get(uuid):
        return redirect(url_for('login'))
    if request.method == 'GET':
        tid = request.args.get('tid')
        if not models.My_qiandao.query.filter(
            and_(models.My_qiandao.qiandao_id == tid, models.My_qiandao.user_id == uuid)).all():
            db.session.add(
                My_qiandao(
                    user_id= uuid,
                    qiandao_id = int(tid)
                        ))
            db.session.commit()
            return redirect(url_for('qiandao'))


@app.route('/xiti', methods=['GET', 'POST'])
def xiti():
    uuid = session.get('uuid')
    if not User.query.get(uuid):
        return redirect(url_for('login'))
    if request.method == 'GET':
        tid = request.args.get('tid')
        datas = []
        results = models.TiMu.query.filter(models.TiMu.kecheng_id==tid).all()
        for resu in results:
            dicts = {}
            dicts['resu'] = resu
            if models.My_timu.query.filter(and_(models.My_timu.timu_id==resu.id,models.My_timu.user_id==uuid)).all():
                dicts['huida'] = models.My_timu.query.filter(and_(models.My_timu.timu_id==resu.id,models.My_timu.user_id==uuid)).all()[0].title
                dicts['status'] = True
            else:
                dicts['status'] = False
            datas.append(dicts)
        return render_template('xuesheng/xiti.html',**locals())
    elif request.method == 'POST':
        tid = request.args.get('tid')
        results = models.TiMu.query.filter(models.TiMu.kecheng_id==tid).all()
        for resu in results:
            content = request.form.get('timu{}'.format(resu.id))
            if content:
                if not models.My_timu.query.filter(
                        and_(models.My_timu.timu_id == resu.id, models.My_timu.user_id == uuid)).all():
                    models.db.session.add(
                        models.My_timu(
                            title= content,
                            user_id = uuid,
                            timu_id = resu.id,
                            fenshu = 0
                        )
                    )
                    models.db.session.commit()
                else:
                    da = models.My_timu.query.filter(
                        and_(models.My_timu.timu_id == resu.id, models.My_timu.user_id == uuid)).all()[0]
                    da.title = content
                    models.db.session.commit()
        return redirect('xiti?tid={}'.format(tid))


@app.route('/add_ziliao', methods=['GET', 'POST'])
def add_ziliao():
    uuid = session.get('uuid')
    if not User.query.get(uuid):
        return redirect(url_for('login'))
    if request.method == 'GET':
        if User.query.get(uuid).type =='admin':
            tid = request.args.get('tid')
            result = models.KeCheng.query.get(tid)
            return render_template('app/add_ziliao.html',**locals())
    elif request.method == 'POST':
        if User.query.get(uuid).type == 'admin':
            tid = request.args.get('tid')
            f1 = request.files['file1']
            print(f1)
            file_name = datetime.datetime.now().strftime('%Y%m%d_%H%M%S__') + f1.filename
            with open(os.path.dirname(os.path.abspath(__file__)) + os.sep + 'static/files/' + file_name ,'wb+')as f:
                f.write(f1.read())
            db.session.add(ZhiLiao(kecheng_id=int(tid), name=file_name))
            db.session.commit()
            return redirect('/ziliao?tid='+tid)

@app.route('/item', methods=['GET', 'POST'])
def item():
    uuid = session.get('uuid')
    if not User.query.get(uuid):
        return redirect(url_for('login'))
    if request.method == 'GET':
        if User.query.get(uuid).type =='admin':
            tid = request.args.get('tid')
            result = models.TongGao.query.get(tid)
            results1 = models.PingLun.query.filter(models.PingLun.tonggao_id==tid).all()

            return render_template('app/item.html',**locals())
        else:
            tid = request.args.get('tid')
            result = models.TongGao.query.get(tid)
            results1 = models.PingLun.query.filter(models.PingLun.tonggao_id==tid).all()
            return render_template('xuesheng/item.html',**locals())

@app.route('/add_pinglun', methods=['GET', 'POST'])
def add_pinglun():
    uuid = session.get('uuid')
    if not User.query.get(uuid):
        return redirect(url_for('login'))
    if request.method == 'POST':
        if User.query.get(uuid).type =='admin':
            tid = request.args.get('tid')
            content = request.form.get('content')
            db.session.add(
                PingLun(user_id=uuid, content=content, tonggao_id=int(tid))
            )
            db.session.commit()
            return redirect('/item?tid='+tid)
        else:
            tid = request.args.get('tid')
            content = request.form.get('content')
            db.session.add(
                PingLun(user_id=uuid, content=content, tonggao_id=int(tid))
            )
            db.session.commit()

            return redirect('/item?tid='+tid)


@app.route('/chengji', methods=['GET', 'POST'])
def chengji():
    uuid = session.get('uuid')
    if not User.query.get(uuid):
        return redirect(url_for('login'))
    if request.method == 'GET':
        datas = ChengJi.query.all()
        return render_template('app/chengji.html',**locals())


@app.route('/user', methods=['GET', 'POST'])
def user():
    uuid = session.get('uuid')
    if not User.query.get(uuid):
        return redirect(url_for('login'))
    if request.method == 'GET':
        if User.query.get(uuid).type == 'admin':
            data = User.query.get(uuid)
            return render_template('app/user.html',**locals())
        else:
            data = User.query.get(uuid)
            return render_template('xuesheng/user.html', **locals())
    elif request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        db.session.query(User).filter(User.id == uuid).update({"name": name,"email":email})
        db.session.commit()
        db.session.close()
        return redirect(url_for('user'))

@app.route('/tonggao', methods=['GET', 'POST'])
def tonggao():
    uuid = session.get('uuid')
    if not User.query.get(uuid):
        return redirect(url_for('login'))
    if request.method == 'GET':
        if User.query.get(uuid).type == 'admin':
            datas = TongGao.query.all()
            return render_template('app/tonggao.html',**locals())
        else:
            datas = TongGao.query.all()
            return render_template('xuesheng/tonggao.html', **locals())





@app.route('/login', methods=['GET', 'POST'])
def login():
    uuid = session.get('uuid')
    datas = User.query.get(uuid)
    if datas:
        return redirect(url_for('index'))
    if request.method=='GET':
        return render_template('account/login.html')
    elif request.method=='POST':
        user = request.form.get('user')
        password = request.form.get('pwd')
        print(user,password)
        type1 = request.form.get('optionsRadiosinline')
        data = User.query.filter(and_(User.name==user,User.pwd==password)).all()
        if not data:
            return render_template('account/login.html',error='账号密码错误')
        elif type1 == 'admin' and data[0].type != 'admin':
            return render_template('account/login.html', error='选择权限错误，该账号无教师权限')
        else:
            session['uuid'] = data[0].id
            session.permanent = True
            if data[0].type == 'admin' and type1 == 'admin':
                return redirect(url_for('jiaoshi'))
            else:
                return redirect(url_for('index'))


@app.route('/loginout', methods=['GET'])
def loginout():
    if request.method == 'GET':
        session['uuid'] = ''
        session.permanent = False
        return redirect(url_for('login'))


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'GET':
        uuid = session.get('uuid')
        datas = User.query.get(uuid)
        if datas:
            return redirect(url_for('index'))
        return render_template('account/signup.html')
    elif request.method == 'POST':
        user = request.form.get('user')
        email = request.form.get('email')
        password = request.form.get('pwd')
        if User.query.filter(User.name == user).all():
            return render_template('account/signup.html', error='账号名已被注册')
        elif user == '' or password == '' or email == '':
            return render_template('account/signup.html', error='输入不能为空')
        else:
            db.session.add(User(name=user, pwd=password,email=email))
            db.session.commit()
            return redirect(url_for('login'))


@app.route('/fenxi1', methods=['GET', 'POST'])
def fenxi1():
    uuid = session.get('uuid')
    if not User.query.get(uuid):
        return redirect(url_for('login'))
    if request.method == 'GET':
        if User.query.get(uuid).type == 'admin':
            return render_template('app/fenxi1.html',**locals())


import pandas
@app.route('/keshihua', methods=['GET', 'POST'])
def keshihua():
    uuid = session.get('uuid')
    if not User.query.get(uuid):
        return redirect(url_for('login'))
    if request.method == 'GET':
        if User.query.get(uuid).type == 'admin':
            brandShowName_name = ['8:00-9:00','9:00-10:00','10:00-11:00','11:00-12:00','12:00-13:00','13:00-14:00','14:00-15:00',
                                  '15:00-16:00','16:00-17:00','17:00-18:00','18:00-19:00','19:00-20:00','20:00-21:00','21:00-22:00']
            brandShowName_xiaoshou = [10,15,18,16,8,11,19,26,34,16,19,24,29,30]

            xuexisss = [
                {"id":1,"xuehao":"12324","name":"刘三","baifenbi":70,"shijian":"10小时"},
                {"id": 2, "xuehao": "17565", "name": "李四", "baifenbi": 54, "shijian": "4小时"},
                {"id": 3, "xuehao": "14298", "name": "王五", "baifenbi": 89, "shijian": "20小时"}
            ]
            xuexisss2 = [
                {"id": 1, "xuehao": "12324", "name": "刘三", "baifenbi": 73, "shijian": "77小时","dengji":'良'},
                {"id": 2, "xuehao": "17565", "name": "李四", "baifenbi": 46, "shijian": "32小时","dengji":'差'},
                {"id": 3, "xuehao": "14298", "name": "王五", "baifenbi": 91, "shijian": "65小时","dengji":'优秀'}
            ]
            datas = models.Qiandao_log.query.all()
            xuexisss3 = []
            manqing = 0
            queyi = 0
            queer = 0
            quesan = 0
            yanzhong = 0
            for resu in datas[:10]:
                if float(resu.fabu) -  float(resu.shiji) > 3:
                    xiangxi = '严重缺勤'
                    yanzhong += 1
                elif float(resu.fabu) -  float(resu.shiji) == 0:
                    xiangxi = '满勤'
                    manqing += 1
                elif float(resu.fabu) -  float(resu.shiji) == 1:
                    xiangxi = '缺一次'
                    queyi += 1
                elif float(resu.fabu) -  float(resu.shiji) == 2:
                    xiangxi = '缺二次'
                    queer += 1
                elif float(resu.fabu) -  float(resu.shiji) == 3:
                    xiangxi = '缺三次'
                    quesan += 1
                dict1 = {"id": resu.id, "xuehao": resu.xuehao, "name": resu.user, "cishu": resu.shiji, "xiangxi": xiangxi}
                xuexisss3.append(dict1)

            # marketPrice_list = [{"name":"满勤","value":manqing},{"name":"缺一次","value":queyi},{"name":"缺二次","value":queer},
            #                     {"name":"缺三次","value":quesan},{"name":"严重缺勤","value":yanzhong}]
            # marketPrice_list = [{"name":"满勤","value":12},{"name":"缺一次","value":51},{"name":"缺二次","value":11},
            #                     {"name":"缺三次","value":6},{"name":"严重缺勤","value":3}]
            marketPrice_list = [
                {"name": "签到消极", "value": len([resu for resu in datas if 50  < float(resu.qiandao_lv) < 70 ])},
                {"name": "签到积极", "value": len([resu for resu in datas if 80  < float(resu.qiandao_lv) < 100 ])},
            ]




            datas11 = models.Average_score.query.all()
            marketPrice_name = []
            marketPrice_xiaoshou = []
            for resu in datas11:
                marketPrice_name.append(resu.title)
                marketPrice_xiaoshou.append(resu.fenshu)


            datas = models.User_Average_score.query.all()
            list1 = [float(resu.fenshu) for resu in datas]
            User_Average_score_list = [{"name": '不合格',"value":len([resu for resu in list1 if 50 <= resu < 60])},
                                       {"name": '合格', "value": len([resu for resu in list1 if 60 <= resu < 70])},
                                       {"name": '中等', "value": len([resu for resu in list1 if 70 <= resu < 80])},
                                       {"name": '良', "value": len([resu for resu in list1 if 80 <= resu < 90])},
                                       {"name": '优', "value": len([resu for resu in list1 if 90 <= resu < 100])},
                                       ]




            return render_template('app/keshihua.html',**locals())


