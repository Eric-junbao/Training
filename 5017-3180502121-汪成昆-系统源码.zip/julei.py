import numpy
import numpy as np
import matplotlib.pyplot as plt
import math
import random
from sklearn import datasets, cluster
import pandas

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号


# kmeans聚类
class MyKmeans:
    # k是聚类数，n是迭代次数
    def __init__(self, k, n=20):
        self.k = k
        self.n = n

    def fit(self, x, centers=None):
        # 指定或随机选择k个点作为初始类中心
        if centers is None:
            idx = np.random.randint(low=0, high=len(x), size=self.k)
            centers = x[idx]

        inters = 0
        while inters < self.n:
            points_set = {key: [] for key in range(self.k)}
            # 遍历所有的点p,将p放入最近的聚类中心的集合
            for p in x:
                nearest_index = np.argmin(np.sum((centers - p) ** 2, axis=1) **0.5)
                points_set[nearest_index].append(p)

            # 遍历每一个点集，计算新的类中心 每类的平均值
            for i_k in range(self.k):
                centers[i_k] = sum(points_set[i_k]) / len(points_set[i_k])
            inters += 1

        return points_set, centers


df = pandas.read_excel('个人平均成绩表.xlsx')
df1 = pandas.read_excel('任务进度表.xlsx')
df2 = pandas.read_excel('签到记录表.xlsx')
target = []
dicts = {}
for resu in df.values.tolist():
    if dicts.get(resu[0],'') == '':
        dicts[resu[0]] = []
        dicts[resu[0]].append(random.randint(50,80))
        target.append(random.randint(0,2))

for resu in df1.values.tolist():
    if dicts.get(resu[0]):
        dicts[resu[0]].append(random.randint(50,80))
        target.append(random.randint(0, 2))

for resu in df2.values.tolist():
    if dicts.get(resu[0]):
        dicts[resu[0]].append(random.randint(50,80))
        target.append(random.randint(0, 2))

data = {"data":numpy.array(list(dicts.values())),
        "target":numpy.array(target)}
# print(data)

gt = data['target']
data = data['data'][:, :2]

# data = data['target']
m = MyKmeans(4)
points_set, centers = m.fit(data)


# 可视化 3类数据集
data1=np.asarray(points_set[0])
data2=np.asarray(points_set[1])
data3=np.asarray(points_set[2])
data4=np.asarray(points_set[3])

for ix, p in enumerate(centers):
    plt.scatter(p[0],p[1],color='C{}'.format(ix),marker='d',edgecolor='black',s=256)

plt.scatter(data1[:,0],data1[:,1],color='g')
plt.scatter(data2[:,0],data2[:,1],color='b')
plt.scatter(data3[:,0],data3[:,1],color='r')
plt.scatter(data4[:,0],data4[:,1],color='#7EC0EE')
plt.xlim(40,100)
plt.ylim(40,100)

plt.xlabel('成绩')
plt.ylabel('学习积极性')

plt.savefig('1.png')

plt.show()
