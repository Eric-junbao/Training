__version__ = '1.5.8'
__author__ = 'Flask-Admin team'
__email__ = 'serge.koval+github@gmail.com'


from .base import expose, expose_plugview, Admin, BaseView, AdminIndexView  # noqa: F401
