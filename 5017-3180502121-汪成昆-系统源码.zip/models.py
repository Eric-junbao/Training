import flask
from flask_sqlalchemy import SQLAlchemy
import datetime
from sqlalchemy import or_,and_
import os
from flask_babelex import Babel

app = flask.Flask(__name__)
abel = Babel(app)
app.config['BABEL_DEFAULT_LOCALE'] = 'zh_CN'

app.config['SECRET_KEY'] = 'xhesheng'

app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL','sqlite:///' + os.path.join(app.root_path, 'xhesheng.db'))
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)


class BanJi(db.Model):
    __tablename__ = 'BanJi'

    id = db.Column(db.Integer, unique=True, primary_key=True)
    name = db.Column(db.String(124), name='班级名')
    banzhuren = db.Column(db.String(124), name='班主任')
    user = db.relationship("User", backref="banji")
    kecheng = db.relationship("KeCheng", backref="banji")
    qiandao = db.relationship("QianDao", backref="banji")

    def __repr__(self):
        return "<{}班级>".format(self.name)

class User(db.Model):
    __tablename__ = 'User'

    id = db.Column(db.Integer, unique=True, primary_key=True)
    name = db.Column(db.String(124),name='账号')
    email = db.Column(db.String(124), name='邮箱')
    pwd = db.Column(db.String(124), name='密码')
    mob = db.Column(db.String(124), name='手机号',default='',nullable=True)
    set = db.Column(db.String(124), name='性别',default='',nullable=True)
    type = db.Column(db.String(124), name='权限',default='vip')
    banji_id = db.Column(db.Integer, db.ForeignKey('BanJi.id'))
    chengji = db.relationship("ChengJi", backref="user")
    pinglun = db.relationship("PingLun", backref="user")
    my_timu = db.relationship("My_timu", backref="user")

    def __repr__(self):
        return "<{}学生>".format(self.name)


class JiaoShi(db.Model):
    __tablename__ = 'JiaoShi'

    id = db.Column(db.Integer, unique=True, primary_key=True)
    name = db.Column(db.String(124),name='账号')
    email = db.Column(db.String(124), name='邮箱')
    pwd = db.Column(db.String(124), name='密码')

    def __repr__(self):
        return "<{}教师>".format(self.name)



class KeCheng(db.Model):
    __tablename__ = 'KeCheng'

    id = db.Column(db.Integer, unique=True, primary_key=True)
    name = db.Column(db.String(124), name='课程名')
    zhaungjie = db.Column(db.String(124), name='章节名称')
    beizhu = db.Column(db.String(124), name='备注')
    banji_id = db.Column(db.Integer, db.ForeignKey('BanJi.id'))
    chengji = db.relationship("ChengJi", backref="kecheng")
    zhiliao = db.relationship("ZhiLiao", backref="kecheng")
    qiandao = db.relationship("QianDao", backref="kecheng")
    timu = db.relationship("TiMu", backref="kecheng")

    def __repr__(self):
        return "<{}课程>".format(self.name)


class ZhiLiao(db.Model):
    __tablename__ = 'ZhiLiao'

    id = db.Column(db.Integer, unique=True, primary_key=True)
    kecheng_id = db.Column(db.Integer, db.ForeignKey('KeCheng.id'))
    name = db.Column(db.String(124), name='资料名')

    def __repr__(self):
        return "<{} 资料>".format(self.name)


class TongGao(db.Model):
    __tablename__ = 'TongGao'

    id = db.Column(db.Integer, unique=True, primary_key=True)
    name = db.Column(db.String(124), name='标题')
    content = db.Column(db.TEXT, name='内容')
    datetime = db.Column(db.DateTime, nullable=True, default=datetime.datetime.now)

    pinglun = db.relationship("PingLun", backref="tonggao")

    def __repr__(self):
        return "<{} 讨论>".format(self.name)


class PingLun(db.Model):
    __tablename__ = 'PingLun'

    id = db.Column(db.Integer, unique=True, primary_key=True)
    name = db.Column(db.String(124), name='标题',default='',nullable=True)
    content = db.Column(db.TEXT, name='内容')
    datetime = db.Column(db.DateTime, nullable=True, default=datetime.datetime.now)
    user_id = db.Column(db.Integer, db.ForeignKey('User.id'))
    tonggao_id = db.Column(db.Integer, db.ForeignKey('TongGao.id'))

    def __repr__(self):
        return "<{} 讨论>".format(self.content)



class ChengJi(db.Model):
    __tablename__ = 'ChengJi'

    id = db.Column(db.Integer, unique=True, primary_key=True)
    fenshu = db.Column(db.String(124), name='分数')
    kecheng_id = db.Column(db.Integer, db.ForeignKey('KeCheng.id'))
    user_id = db.Column(db.Integer, db.ForeignKey('User.id'))
    datetime = db.Column(db.DateTime, nullable=True, default=datetime.datetime.now)

    def __repr__(self):
        return "<{}成绩>".format(self.fenshu)


class QianDao(db.Model):
    __tablename__ = 'QianDao'

    id = db.Column(db.Integer, unique=True, primary_key=True)
    title = db.Column(db.String(124), name='标题')
    faburen =  db.Column(db.String(124), name='发布人')
    kecheng_id = db.Column(db.Integer, db.ForeignKey('KeCheng.id'))
    banji_id = db.Column(db.Integer, db.ForeignKey('BanJi.id'))
    datetime = db.Column(db.DateTime, nullable=True, default=datetime.datetime.now)
    my_qiandao = db.relationship("My_qiandao", backref="qiandao")



    def __repr__(self):
        return "<{}签到>".format(self.title)


class My_qiandao(db.Model):
    __tablename__ = 'My_qiandao'

    id = db.Column(db.Integer, unique=True, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('User.id'))
    qiandao_id = db.Column(db.Integer, db.ForeignKey('QianDao.id'))
    datetime = db.Column(db.DateTime, nullable=True, default=datetime.datetime.now)

    def __repr__(self):
        return "<{}用户签到>".format(self.user_id)



class TiMu(db.Model):
    __tablename__ = 'TiMu'

    id = db.Column(db.Integer, unique=True, primary_key=True)
    title = db.Column(db.TEXT, name='题目')
    kecheng_id = db.Column(db.Integer, db.ForeignKey('KeCheng.id'))
    datetime = db.Column(db.DateTime, nullable=True, default=datetime.datetime.now)

    my_timu = db.relationship("My_timu", backref="timu")

    def __repr__(self):
        return "<{}作业>".format(self.title)


class My_timu(db.Model):
    __tablename__ = 'My_timu'

    id = db.Column(db.Integer, unique=True, primary_key=True)
    title = db.Column(db.TEXT, name='回答')
    user_id = db.Column(db.Integer, db.ForeignKey('User.id'))
    timu_id = db.Column(db.Integer, db.ForeignKey('TiMu.id'))
    fenshu = db.Column(db.Float, name='分数')
    datetime = db.Column(db.DateTime, nullable=True, default=datetime.datetime.now)

    def __repr__(self):
        return "<{}作业>".format(self.title)

class Average_score(db.Model):
    __tablename__ = 'Average_score'

    id = db.Column(db.Integer, unique=True, primary_key=True)
    title = db.Column(db.String(124), name='章节')
    fenshu = db.Column(db.Float, name='分数')


class Login_log(db.Model):
    __tablename__ = 'Login_log'

    id = db.Column(db.Integer, unique=True, primary_key=True)
    user = db.Column(db.String(124), name='用户名')
    datetime = db.Column(db.DateTime, nullable=True, default=datetime.datetime.now)

class Qiandao_log(db.Model):
    __tablename__ = 'Qiandao_log'

    id = db.Column(db.Integer, unique=True, primary_key=True)
    xuehao = db.Column(db.String(124), name='学号')
    user = db.Column(db.String(124), name='姓名')
    fabu = db.Column(db.String(124), name='发布签到数')
    shiji = db.Column(db.String(124), name='实际签到数')
    qiandao_lv = db.Column(db.String(124), name='签到率')


class Progress_task(db.Model):
    __tablename__ = 'Progress_task'

    id = db.Column(db.Integer, unique=True, primary_key=True)
    xuehao = db.Column(db.String(124), name='学号')
    user = db.Column(db.String(124), name='姓名')
    renwu = db.Column(db.String(124), name='任务进度')


class User_Average_score(db.Model):
    __tablename__ = 'User_Average_score'

    id = db.Column(db.Integer, unique=True, primary_key=True)
    xuehao = db.Column(db.String(124), name='学号')
    user = db.Column(db.String(124), name='姓名')
    fenshu = db.Column(db.String(124), name='平均成绩')



if __name__ == '__main__':
    # db.drop_all()
    db.create_all()



